<?php defined('BASEPATH') OR exit('No direct script access allowed'); ?>
<style>
.footer {
  width:100%;
  position:fixed;
  bottom:0;
  left:0;
  padding:0px;
   z-index: 3;
    color:white;
 
  
}
</style>
<head>
<meta charset="utf-8" />
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<div class="footer w3-gray">
<p align="center"><b>©Copyright. All rights reserved.</b></p>
</div>
