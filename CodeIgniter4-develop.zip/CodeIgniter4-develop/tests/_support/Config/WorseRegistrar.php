<?php namespace Tests\Support\Config;

/**
 * Class WorseRegistrar
 *
 * Doesn't provides a basic registrar class for testing BaseConfig registration functions,
 * since it is missing the RegistrarConfig method.
 */
class WorseRegistrar
{

}
