<table>
    <tbody>
    {userFiles}
        <tr>
            <td>{name}</td>
            <td>{path}</td>
        </tr>
    {/userFiles}
    {coreFiles}
        <tr class="muted">
            <td style="width: 20em;">{name}</td>
            <td>{path}</td>
        </tr>
    {/coreFiles}
    </tbody>
</table>
