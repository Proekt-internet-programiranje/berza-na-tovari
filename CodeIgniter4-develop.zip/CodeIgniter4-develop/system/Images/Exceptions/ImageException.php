<?php namespace CodeIgniter\Images\Exceptions;

class ImageException extends \RuntimeException{}
