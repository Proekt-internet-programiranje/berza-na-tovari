<?php

return [
	'invalidRoute' => '{0, string} is not a valid route.',
];
