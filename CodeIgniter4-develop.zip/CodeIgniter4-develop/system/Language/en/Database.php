<?php

return [
	'invalidEvent' => '{0, string} is not a valid Model Event callback.',
];
