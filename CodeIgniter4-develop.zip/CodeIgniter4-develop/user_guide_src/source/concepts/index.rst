#####################
CodeIgniter4 Overview
#####################

The following pages describe the architectural concepts behind CodeIgniter4:

.. toctree::
	:titlesonly:

	structure
	mvc
	autoloader
	services
	http
	security